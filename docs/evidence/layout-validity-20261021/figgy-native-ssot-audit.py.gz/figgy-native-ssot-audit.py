import sys,json,hashlib,time
from pathlib import Path
sys.path.insert(0,'/workspace/figgy-python/tests')
sys.path.insert(0,'/workspace/figgy-python/scripts')
import figgyplot as fg
from test_radial_desktop import Inputs
from test_interaction_parity import drag_native
from measure_layout_validity import NATIVE_SETUP,margins
out=Path('/tmp/figgy-ssot-audit')
rows=[]
def h(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
with fg.Figure(backend='native') as fig:
 exec(NATIVE_SETUP,{'fig':fig});handle=fig.show(block=False)
 try:
  inputs=Inputs(handle);initial=inputs.info();a=initial['decorations']['data_area'];s=initial['chart_panel'][2]/960
  inputs.click_rect([a[0]+a[2]-2+45*s,a[1]+a[3]*.4,0,0])
  title=inputs.info()['decorations']['overlay_0:axis_title_right'];inputs.click_rect(initial['decorations']['axis_left'])
  drag_native(inputs,(title[0]+title[2]/2,title[1]+title[3]/2),(16*s,12*s))
  baseline=fig.get_settings();base_revision=fig.revision
  for w,height in ((1312,744),(900,520),(1312,845),(1312,744)):
   inputs.xdo('windowsize',inputs.wid,w,height)
   for _ in range(3):inputs.pump()
   state=fig.get_settings();info=inputs.info()
   row={'requested':[w,height],'ssot':state,'hash':h(state),'same_as_baseline':state==baseline,'revision':fig.revision,
        'revision_unchanged':fig.revision==base_revision,'info':info,
        'text_bounds':margins(info['controls']['text'],info['controls']['properties_viewport'])}
   rows.append(row);print('native',row['requested'],'same_ssot',row['same_as_baseline'],'same_revision',row['revision_unchanged'],flush=True)
  before=fig.get_settings()
  inputs.click('text');inputs.key('ctrl+a');inputs.xdo('type','--clearmodifiers','Pressure audit');inputs.pump();inputs.key('Return')
  changed=fig.get_settings();actual=''.join(s['text'] for s in changed['config']['overlays'][0]['y_axis']['title_option']['text']['segments'])
  rows.append({'phase':'actual_text_edit','before_ssot':before,'after_ssot':changed,'actual_text':actual,'expected_text':'Pressure audit','passed':actual=='Pressure audit'})
  print('native actual edit',actual=='Pressure audit',flush=True)
 finally:handle.close();Inputs.pump()
(out/'native.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
