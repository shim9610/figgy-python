import sys, json, time, hashlib, copy
from pathlib import Path
sys.path.insert(0,'/workspace/figgy-python/tests')
sys.path.insert(0,'/workspace/figgy-python/scripts')
from jupyter_harness import notebook
from measure_layout_validity import BROWSER_SNAPSHOT,browser_settle,xywh,margins
ROOT="document.querySelector('.figgy-editor').figgy"
out=Path('/tmp/figgy-ssot-audit');out.mkdir(exist_ok=False)
rows=[]

def canonical(v):
 if isinstance(v,dict):return {k:canonical(x) for k,x in v.items()}
 if isinstance(v,list):return [canonical(x) for x in v]
 if isinstance(v,float) and v.is_integer():return int(v)
 return v

def digest(v):return hashlib.sha256(json.dumps(canonical(v),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def diff(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  rows=[]
  for k in sorted(a.keys()|b.keys()):
   p=path+'/'+k
   if k not in a:rows.append({'path':p,'before_missing':True,'after':b[k]})
   elif k not in b:rows.append({'path':p,'before':a[k],'after_missing':True})
   else:rows.extend(diff(a[k],b[k],p))
  return rows
 if isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):return [{'path':path,'before_length':len(a),'after_length':len(b),'before':a,'after':b}]
  return [r for i,(x,y) in enumerate(zip(a,b)) for r in diff(x,y,path+f'/{i}')]
 return [] if a==b else [{'path':path,'before':a,'after':b}]

source="""import json
import figgyplot as fg
fig,ax=fg.subplots(backend='webgpu')
ax.plot([0,1,2],[1,3,2])
ax.text(.95,.95,'Probe',coords='ratio',fontsize=16*72/fig.dpi,id='probe')
display(fig.widget())
"""
with notebook(out/'notebook',source) as (page,execute):
 page.evaluate("""()=>{window.figgyValidityResizeEvents=[];addEventListener('resize',()=>window.figgyValidityResizeEvents.push({now:performance.now(),viewport:[innerWidth,innerHeight]}));}""")
 def settings():return json.loads(execute('print(json.dumps(fig.get_settings()))'))
 def capture(label):
  ssot=page.evaluate(ROOT+'.snapshot()');py=settings();snapshot=page.evaluate(BROWSER_SNAPSHOT)
  row={'phase':label,'browser_ssot':ssot,'python_ssot':py,'browser_hash':digest(ssot),'python_hash':digest(py),
       'cross_host_diff':diff(py,ssot),'view':snapshot}
  rows.append(row)
  (out/'browser.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
  print(label,'cross_host_diff',len(row['cross_host_diff']),'font',snapshot['modelFont'],snapshot['nodes']['[data-inline-text]']['fontSize'],flush=True)
  return row
 def resize(w,h):
  before=page.evaluate('[innerWidth,innerHeight,devicePixelRatio]');page.evaluate('window.figgyValidityResizeEvents=[]')
  page.set_viewport_size({'width':w,'height':h})
  return browser_settle(page,[w,h,1],before[:2]!=[w,h])
 page.evaluate(ROOT+'.flush()')
 entries=page.evaluate(ROOT+'.annotations()');r=entries[0]['rect']
 point=page.locator('canvas').evaluate('(c,p)=>{const r=c.getBoundingClientRect();return [r.x+p[0]*r.width/c.width,r.y+p[1]*r.height/c.height]}',[r[0]+8,r[1]+6])
 page.mouse.dblclick(*point);entry=page.locator('[data-inline-text]');entry.wait_for(state='visible')
 entry.fill('First\nSecond')
 resize(1500,1000)
 baseline=capture('draft_before_resize')
 resize(640,600);small=capture('draft_after_shrink')
 resize(1500,1000);large=capture('draft_after_grow')
 page.wait_for_timeout(2000);idle=capture('draft_gpu_idle')
 for r in rows:
  r['browser_diff_from_baseline']=diff(baseline['browser_ssot'],r['browser_ssot'])
  r['python_diff_from_baseline']=diff(baseline['python_ssot'],r['python_ssot'])
 # Actual keyboard editing at the wrong-layout state, no repair intervention.
 before=entry.input_value();entry.press('Control+End');entry.type('!')
 keyboard=capture('actual_keyboard_edit_before_apply')
 keyboard['draft_edit_expected']=before+'!';keyboard['draft_edit_pass']=entry.input_value()==before+'!'
 entry.press('Enter');page.evaluate(ROOT+'.flush()')
 committed=capture('after_enter_apply')
 committed['browser_diff_from_baseline']=diff(baseline['browser_ssot'],committed['browser_ssot'])
 committed['python_diff_from_baseline']=diff(baseline['python_ssot'],committed['python_ssot'])
 committed['actual_text']=''.join(s['text'] for s in committed['python_ssot']['config']['annotations']['items'][0]['kind']['Text']['text']['segments'])
 committed['expected_text']='First\nSecond!'
 committed['apply_pass']=committed['actual_text']==committed['expected_text']
 (out/'browser.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 print('RESIZE BROWSER SSOT DIFFS',[(r['phase'],len(r.get('browser_diff_from_baseline',[])),len(r.get('python_diff_from_baseline',[]))) for r in rows[:4]],flush=True)
 print('KEYBOARD',keyboard['draft_edit_pass'],'APPLY',committed['apply_pass'],'cross_host_diff',committed['cross_host_diff'],flush=True)
